package adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lso_libreria.R;

import java.util.List;

import model.Libro;

public class CarrelloAdapter extends RecyclerView.Adapter<CarrelloAdapter.CarrelloViewHolder> {

    private final List<Libro> libri;
    private final RisultatiAdapter.OnItemClickListener listener;

    public CarrelloAdapter(List<Libro> libri, RisultatiAdapter.OnItemClickListener listener) {
        this.libri = libri;
        this.listener = listener;
    }

    public interface OnItemClickListener {
        void onItemClick(Libro libro);
    }

    @NonNull
    @Override
    public CarrelloViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_item_libro, parent, false);
        return new CarrelloViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CarrelloViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public static class CarrelloViewHolder extends RecyclerView.ViewHolder {

        public CarrelloViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
