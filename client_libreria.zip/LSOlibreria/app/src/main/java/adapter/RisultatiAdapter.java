package adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lso_libreria.R;

import java.util.List;

import model.Libro;

public class RisultatiAdapter extends RecyclerView.Adapter<RisultatiAdapter.RisultatiViewHolder> {

    private final List<Libro> risultati;
    private final OnItemClickListener listener;

    public RisultatiAdapter(List<Libro> risultati, OnItemClickListener listener) {
        this.risultati = risultati;
        this.listener = listener;
    }

    public interface OnItemClickListener {
        void onItemClick(Libro libro);
    }

    @NonNull
    @Override
    public RisultatiViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_item_libro, parent, false);
        return new RisultatiViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RisultatiViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public static class RisultatiViewHolder extends RecyclerView.ViewHolder{

        public RisultatiViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
