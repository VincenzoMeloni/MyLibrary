package enums;

import java.util.ArrayList;
import java.util.List;

public enum Genere {
    FANTASY("Fantasy"),
    THRILLER("Thriller"),
    SCI_FI("Sci-Fi"),
    ROMANZO("Romanzo"),
    STORIA("Storia");

    private final String nome;

    Genere(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public String toString() {
        return nome;
    }

    // Metodo per ottenere un elenco di tutti i generi
    public static List<String> getAllGeneri() {
        List<String> generi = new ArrayList<>();
        for (Genere genere : Genere.values()) {
            generi.add(genere.getNome());
        }
        return generi;
    }
}
