package com.example.lso_libreria;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import model.Libro;

public class RisultatiRicercaActivity extends AppCompatActivity {

    private ImageButton back,carrello,home;
    private List<Libro> libri;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_risultati_ricerca);

        back = findViewById(R.id.back_button);
        carrello = findViewById(R.id.carrello);
        home = findViewById(R.id.home);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityCerca();
                finish();
            }
        });

        carrello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityCarrello();
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openHomeActivity();
            }
        });


    }

    private void openActivityCerca(){
        Intent intentC = new Intent(this, CercaActivity.class);
        startActivity(intentC);
    }

    protected void openActivityCarrello(){
        Intent intent = new Intent(this, CarrelloActivity.class);
        startActivity(intent);
    }

    private void openHomeActivity(){
        Intent intentH = new Intent(this, HomeActivity.class);
        startActivity(intentH);
    }
}
