package com.example.lso_libreria;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import enums.Genere;

public class CercaActivity extends AppCompatActivity {

    private final Genere[] items = Genere.values();
    private AutoCompleteTextView autoCompleteTextView;
    private EditText cerca_input;
    private Button vai,disponibili;
    private ImageButton back, carrello;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cerca);

        cerca_input = findViewById(R.id.cerca_input);
        vai = findViewById(R.id.vaiButton);
        back = findViewById(R.id.back_button);
        disponibili = findViewById(R.id.disponibili_button);
        autoCompleteTextView = findViewById(R.id.auto_complete_txt);
        carrello = findViewById(R.id.carrello);


        ArrayAdapter<Genere> adapterItems = new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line, items);

        autoCompleteTextView.setAdapter(adapterItems);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityHome();
                finish();
            }
        });

        carrello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityCarrello();
            }
        });

        vai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityRisultatiRicerca();
            }
        });


        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(), "Genere Selezionato: " + item, Toast.LENGTH_SHORT).show();
            }
        });




    }


    private void openActivityHome(){
        Intent intentH = new Intent(this, HomeActivity.class);
        startActivity(intentH);
    }

    private void openActivityCarrello(){
        Intent intent = new Intent(this, CarrelloActivity.class);
        startActivity(intent);
    }

    private void openActivityRisultatiRicerca(){
        Intent intentR = new Intent(this, RisultatiRicercaActivity.class);
        startActivity(intentR);
    }
}
