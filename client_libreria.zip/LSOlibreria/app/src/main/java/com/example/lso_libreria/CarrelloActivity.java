package com.example.lso_libreria;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import model.Libro;

public class CarrelloActivity extends AppCompatActivity {

    private ImageButton back;
    private Button rimuovi,checkout;
    private List<Libro> libri;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrello);

        back = findViewById(R.id.back_button);
        rimuovi = findViewById(R.id.remove_button);
        checkout = findViewById(R.id.checkout_button);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityHome();
                finish();
            }
        });


    }


    private void openActivityHome(){
        Intent intentH = new Intent(this, HomeActivity.class);
        startActivity(intentH);
    }
}
