package com.example.lso_libreria;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class ProfiloActivity extends AppCompatActivity {

    private ImageButton back,carrello;
    private AlertDialog.Builder builder;
    private Button logout,modpass;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profilo);

        back = findViewById(R.id.back_button);
        logout = findViewById(R.id.logoutButton);
        modpass = findViewById(R.id.PassButton);
        carrello = findViewById(R.id.carrello);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openHomeActivity();
                finish();
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                disconnect();
            }
        });

        modpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityModPass();
            }
        });

        carrello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityCarrello();
            }
        });


    }

    protected void openActivityCarrello(){
        Intent intent = new Intent(this, CarrelloActivity.class);
        startActivity(intent);
    }

    private void openHomeActivity(){
        Intent intentH = new Intent(this, HomeActivity.class);
        startActivity(intentH);
    }
    private void disconnect() {
        builder = new AlertDialog.Builder(ProfiloActivity.this);
        builder.setMessage("Sei sicuro di voler uscire?")
                .setCancelable(true)
                .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogInterface, int i) {
                        openActivityLogin();
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                })
                .show();
    }

    private void openActivityLogin(){
        Intent intentL = new Intent(this, LoginActivity.class);
        startActivity(intentL);
    }

    private void openActivityModPass(){
        Intent intentP = new Intent(this, ModificaPasswordActivity.class);
        startActivity(intentP);
    }

}
