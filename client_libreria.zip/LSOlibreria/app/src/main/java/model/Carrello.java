package model;

public class Carrello {
    private int userId;
    private int libroId;

    public Carrello(int userId,int libroId){
        setUserId(userId);
        setLibroId(libroId);
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getLibroId() {
        return libroId;
    }

    public void setLibroId(int libroId) {
        this.libroId = libroId;
    }
}
