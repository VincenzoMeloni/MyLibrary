package controller;

public class Comandi {

    // Server OK
    public static final String LOGIN_OK = "101";
    public static final String REG_OK = "102";
    public static final String CERCA_LIBRO_OK = "103";
    public static final String CERCA_LIBRO_GENERE_OK = "104";
    public static final String CERCA_LIBRO_DISPONIBILI_OK = "105";
    public static final String ADD_CARRELLO_OK = "106";
    public static final String REM_CARRELLO_OK = "107";
    public static final String CHECKOUT_OK = "108";
    public static final String MODPASS_OK = "109";
    public static final String VISUALIZZA_CARRELLO_OK = "110";

    // Server ERR
    public static final String LOGIN_ERR = "201";
    public static final String REG_ERR = "202";
    public static final String CERCA_LIBRO_ERR = "203";
    public static final String CERCA_LIBRO_GENERE_ERR = "204";
    public static final String CERCA_LIBRO_DISPONIBILI_ERR = "205";
    public static final String ADD_CARRELLO_ERR = "206";
    public static final String REM_CARRELLO_ERR = "207";
    public static final String CHECKOUT_ERR = "208";
    public static final String MODPASS_ERR = "209";
    public static final String VISUALIZZA_CARRELLO_ERR = "210";
    public static final String MAXPRESTITI_ERR = "211";

    // Client
    public static final String LOGIN = "1";
    public static final String REG = "2";
    public static final String CERCA_LIBRO = "3";
    public static final String CERCA_LIBRO_GENERE = "4";
    public static final String CERCA_LIBRO_DISPONIBILI = "5";
    public static final String AGGIUNGI_CARRELLO = "6";
    public static final String RIMUOVI_CARRELLO = "7";
    public static final String CHECKOUT = "8";
    public static final String MODPASS = "9";
    public static final String VISUALIZZA_CARRELLO = "10";

    // Errori Generali
    public static final String LOGINNONTROVATO = "301";
    public static final String GIAREGISTRATO = "302";
    public static final String LIBRONONDISPONIBILE = "305";
    public static final String VECCHIAPASSWORDERRATA = "306";

}
