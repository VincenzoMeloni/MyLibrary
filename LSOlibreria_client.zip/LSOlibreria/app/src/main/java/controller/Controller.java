package controller;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import model.Libro;
import model.Utente;

public class Controller {
    private Socket socket;
    private static Controller controller;
    private int comando;
    private String risposta;
    private String[] dati = new String[0];
    private static final int SERVERPORT = 5050;
    private static final String IP_SERVER = "192.168.68.107";
    private Utente u;
    private static Controller instance = null;
    private List<Libro> libri;


    public Controller(){
        this.u = null;
    }

    public static Controller getInstance() {
        if (instance == null) {
            instance = new Controller();
        }
        return instance;
    }


    public void ConnettiServer() throws IOException {
        if (socket == null || socket.isClosed()) {
            try {
                socket = new Socket(IP_SERVER, SERVERPORT);  // Connessione al server
            } catch (IOException e) {
                System.out.println("Errore durante la connessione al server: " + e.getMessage());
                throw e;
            }
        }
    }


    public void DisconnettiServer() {
        try {
            if (socket != null && !socket.isClosed())
                socket.close();
        }catch(IOException e){
            System.out.println("Errore durante la disconnessione dal server: " + e.getMessage());
        }
    }

    private int InviaRichiesta(String richiesta){
        try{
            ConnettiServer();
            OutputStream outputStream = socket.getOutputStream();
            InputStream inputStream = socket.getInputStream();

            //invio
            outputStream.write(richiesta.getBytes());
            outputStream.flush();

            //ricezione risposta
            byte[] buffer = new byte[2048];
            int bytesRead = inputStream.read(buffer);

            if(bytesRead < 0){
                System.out.println("Errore nella ricezione della risposta dal server!\n");
                return -1;
            }

            //conversione risposta in stringa
            String risposta = new String(buffer,0,bytesRead);
            String[] dati = risposta.split("\\|");



            comando = Integer.parseInt(dati[0].replaceAll("[^0-9]", ""));

            return comando;

        }catch(IOException e){
            System.out.println("Errore nella comunicazione con il server: " + e.getMessage());
            return -1;
        }finally{
            DisconnettiServer();
        }
    }

    private String[] inviaRichiestaString(String richiesta){
        try{
            ConnettiServer();
            OutputStream outputStream = socket.getOutputStream();
            InputStream inputStream = socket.getInputStream();

            //invio
            outputStream.write(richiesta.getBytes());
            outputStream.flush();

            //ricezione risposta
            byte[] buffer = new byte[2048];
            int bytesRead = inputStream.read(buffer);

            if(bytesRead < 0)
                System.out.println("Errore nella ricezione della risposta dal server!\n");


            //conversione risposta in stringa
            String risposta = new String(buffer,0,bytesRead);
            dati = risposta.split("\\|");


            comando = Integer.parseInt(dati[0].replaceAll("[^0-9]", ""));


        }catch(IOException e){
            System.out.println("Errore nella comunicazione con il server: " + e.getMessage());
        }finally{
            DisconnettiServer();
        }
        return dati;
    }


    public String[] login(String username, String password) throws Exception{
        String richiesta = Comandi.LOGIN + "|" + username + "|" + password;

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                dati = inviaRichiestaString(richiesta);
            }
        });

        t.start(); // Avvio del thread
        t.join(); // Attendo la terminazione del thread

        return dati;
    }

    public int registrazione(String username, String password) throws Exception{
        String richiesta = Comandi.REG + "|" + username + "|" + password;

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                comando = InviaRichiesta(richiesta);
            }
        });

        t.start(); // Avvio del thread
        t.join(); // Attendo la terminazione del thread

        return comando;
    }

    public String[] cercaLibri(String testo) throws InterruptedException {
        String richiesta = Comandi.CERCA_LIBRO + "|" + testo;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
              dati = inviaRichiestaString(richiesta);
            }
        });
        t.start(); // Avvio del thread
        t.join(); // Attendo la terminazione del thread

        return dati;

    }

    public String[] cercaLibriPerGenere(String genere) throws InterruptedException {
        String richiesta = Comandi.CERCA_LIBRO_GENERE + "|" + genere;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                dati = inviaRichiestaString(richiesta);
            }
        });
        t.start(); // Avvio del thread
        t.join(); // Attendo la terminazione del thread

        return dati;

    }

    public String[] cercaLibriDisponibili() throws InterruptedException {
        String richiesta = Comandi.CERCA_LIBRO_DISPONIBILI;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                dati = inviaRichiestaString(richiesta);
            }
        });
        t.start(); // Avvio del thread
        t.join(); // Attendo la terminazione del thread

        return dati;

    }

    public int addCarrello(int libroId) throws InterruptedException {
        String richiesta = Comandi.AGGIUNGI_CARRELLO + "|" + u.getId_utente() + "|" + libroId;

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                comando = InviaRichiesta(richiesta);
            }
        });

        t.start(); // Avvio del thread
        t.join(); // Attendo la terminazione del thread

        return comando;
    }

    public int remCarrello(int libroId) throws InterruptedException {
        String richiesta = Comandi.RIMUOVI_CARRELLO + "|" + u.getId_utente() + "|" + libroId;

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                comando = InviaRichiesta(richiesta);
            }
        });

        t.start(); // Avvio del thread
        t.join(); // Attendo la terminazione del thread

        return comando;
    }

    public int checkout() throws InterruptedException {
        String richiesta = Comandi.CHECKOUT + "|" + u.getId_utente();

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                comando = InviaRichiesta(richiesta);
            }
        });

        t.start(); // Avvio del thread
        t.join(); // Attendo la terminazione del thread

        return comando;
    }

    public int aggiornaPassword(String vecchiaPass, String nuovaPass) throws InterruptedException {
        String richiesta = Comandi.MODPASS + "|" + u.getId_utente() + "|" + vecchiaPass + "|" + nuovaPass;

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                comando = InviaRichiesta(richiesta);
            }
        });

        t.start(); // Avvio del thread
        t.join(); // Attendo la terminazione del thread

        return comando;
    }

    public String[] visualizzaCarrello() throws InterruptedException {
        String richiesta = Comandi.VISUALIZZA_CARRELLO + "|" + u.getId_utente();
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                dati = inviaRichiestaString(richiesta);
            }
        });
        t.start(); // Avvio del thread
        t.join(); // Attendo la terminazione del thread

        return dati;

    }



    public void setUtente(Utente utente) {
        this.u = utente;
    }

    public Utente getUtente() { return this.u; }

    public void setLibro(Libro libro){
        if(libri == null)
            libri = new ArrayList<>();
        libri.add(libro);
    }

    public Libro getLibroById(int id){
        for(Libro libro : libri){
            if(libro.getId_libro() == id)
                return libro;
        }
        return null;
    }

}
