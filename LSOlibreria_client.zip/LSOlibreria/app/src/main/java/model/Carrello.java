package model;

public class Carrello {
    private int userId;
    private int libroId;
    private boolean is_checkout;

    public Carrello(int userId,int libroId,boolean is_checkout){
        setUserId(userId);
        setLibroId(libroId);
        setIs_checkout(is_checkout);
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getLibroId() {
        return libroId;
    }

    public void setLibroId(int libroId) {
        this.libroId = libroId;
    }

    public boolean isIs_checkout() {
        return is_checkout;
    }

    public void setIs_checkout(boolean is_checkout) {
        this.is_checkout = is_checkout;
    }
}
