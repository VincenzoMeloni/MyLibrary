package model;


public class Libro {
    private int id_libro;
    private String titolo;
    private String autore;
    private String genere;
    private int num_copie_tot;
    private int num_copie_disponibili;
    private int quantita;

    public Libro(int id_libro,String titolo,String autore,int num_copie_disponibili,String genere,int quantita){
        setId_libro(id_libro);
        setTitolo(titolo);
        setAutore(autore);
        setGenere(genere);
        setNum_copie_tot(num_copie_tot);
        setNum_copie_disponibili(num_copie_disponibili);
        setQuantita(quantita);
    }

    public int getId_libro() {
        return id_libro;
    }

    public void setId_libro(int id_libro) {
        this.id_libro = id_libro;
    }

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public String getAutore() {
        return autore;
    }

    public void setAutore(String autore) {
        this.autore = autore;
    }

    public int getNum_copie_tot() {
        return num_copie_tot;
    }

    public void setNum_copie_tot(int num_copie_tot) {
        this.num_copie_tot = num_copie_tot;
    }

    public int getNum_copie_disponibili() {
        return num_copie_disponibili;
    }

    public void setNum_copie_disponibili(int num_copie_disponibili) {
        this.num_copie_disponibili = num_copie_disponibili;
    }

    public String getGenere() {
        return genere;
    }

    public void setGenere(String genere) {
        this.genere = genere;
    }

    public int getQuantita() {
        return quantita;
    }

    public void setQuantita(int quantita) {
        this.quantita = quantita;
    }
}
