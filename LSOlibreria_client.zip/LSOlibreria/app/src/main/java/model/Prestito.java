package model;

import java.util.Date;

public class Prestito {
    private int id_prestito;
    private int id_libro;
    private int id_utente;
    private Date data_prestito;
    private Date data_scadenza;
    private boolean restituito;

    public Prestito(int id_prestito,int id_libro,int id_utente,Date data_prestito,Date data_scadenza,boolean restituito){
        setId_prestito(id_prestito);
        setId_libro(id_libro);
        setId_utente(id_utente);
        setData_prestito(data_prestito);
        setData_scadenza(data_scadenza);
        setRestituito(restituito);
    }


    public int getId_prestito() {
        return id_prestito;
    }

    public void setId_prestito(int id_prestito) {
        this.id_prestito = id_prestito;
    }

    public int getId_libro() {
        return id_libro;
    }

    public void setId_libro(int id_libro) {
        this.id_libro = id_libro;
    }

    public int getId_utente() {
        return id_utente;
    }

    public void setId_utente(int id_utente) {
        this.id_utente = id_utente;
    }

    public Date getData_prestito() {
        return data_prestito;
    }

    public void setData_prestito(Date data_prestito) {
        this.data_prestito = data_prestito;
    }

    public Date getData_scadenza() {
        return data_scadenza;
    }

    public void setData_scadenza(Date data_scadenza) {
        this.data_scadenza = data_scadenza;
    }

    public boolean isRestituito() {
        return restituito;
    }

    public void setRestituito(boolean restituito) {
        this.restituito = restituito;
    }
}
