package model;

import java.util.Date;

public class Prestito {
    private int id_prestito;
    private int id_utente;
    private Date data_prestito;
    private Date data_scadenza;
    private boolean restituito;
    private int libriInPrestito;
    private Libro libro;

    public Prestito(int id_utente,Date data_prestito,Date data_scadenza,boolean restituito,int libriInPrestito,Libro libro){
        setId_utente(id_utente);
        setData_prestito(data_prestito);
        setData_scadenza(data_scadenza);
        setRestituito(restituito);
        setLibriInPrestito(libriInPrestito);
        setLibro(libro);
    }


    public int getId_prestito() {
        return id_prestito;
    }

    public void setId_prestito(int id_prestito) {
        this.id_prestito = id_prestito;
    }

    public int getId_utente() {
        return id_utente;
    }

    public void setId_utente(int id_utente) {
        this.id_utente = id_utente;
    }

    public Date getData_prestito() {
        return data_prestito;
    }

    public void setData_prestito(Date data_prestito) {
        this.data_prestito = data_prestito;
    }

    public Date getData_scadenza() {
        return data_scadenza;
    }

    public void setData_scadenza(Date data_scadenza) {
        this.data_scadenza = data_scadenza;
    }

    public boolean isRestituito() {
        return restituito;
    }

    public void setRestituito(boolean restituito) {
        this.restituito = restituito;
    }

    public int getLibriInPrestito() {
        return libriInPrestito;
    }

    public void setLibriInPrestito(int libriInPrestito) {
        this.libriInPrestito = libriInPrestito;
    }

    public Libro getLibro() {
        return libro;
    }

    public void setLibro(Libro libro) {
        this.libro = libro;
    }
}
