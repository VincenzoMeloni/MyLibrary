package com.example.lso_libreria;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


import controller.Comandi;
import controller.Controller;

public class RegistrazioneActivity extends AppCompatActivity {

    private ImageButton back;
    private EditText username;
    private EditText password;
    private EditText confPassword;
    private Button regButton;
    private Controller controller;
    private int comando;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrazione);

        back = findViewById(R.id.back_button);
        username = findViewById(R.id.usernameEditText);
        password = findViewById(R.id.passwordEditText);
        confPassword = findViewById(R.id.ConfpasswordEditText);
        regButton = findViewById(R.id.RegButton);

        controller = new Controller();

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityLogin();
                finish();
            }
        });


        regButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String cpass = confPassword.getText().toString();

                AlertDialog.Builder builder = new AlertDialog.Builder(RegistrazioneActivity.this);

                if(user.length() == 0 || pass.length() == 0 || cpass.length() == 0){
                    builder.setMessage("Bisogna riempire tutti i campi!")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                }
                            });
                    AlertDialog alert = builder.create();
                    alert.show();
                    username.setText("");
                    password.setText("");
                    confPassword.setText("");
                    return;
                }
                else if(!pass.equals(cpass)){
                    builder.setMessage("Le password non corrispondono, riprova")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                }
                            });
                    AlertDialog alert = builder.create();
                    alert.show();
                    password.setText("");
                    confPassword.setText("");
                }
                else{
                    try {
                        comando = controller.registrazione(user, pass);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }

                    if(comando == Integer.parseInt(Comandi.REG_OK)) {
                        builder.setMessage("Registrazione avvenuta con Successo! Effettua il login!")
                                .setCancelable(false)
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        openActivityLogin();
                                    }
                                });
                        AlertDialog alert = builder.create();
                        alert.show();
                    }else if(comando == Integer.parseInt(Comandi.REG_ERR)) {
                        builder.setMessage("Errore durante la registrazione. Riprova!")
                                .setCancelable(false)
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                    }
                                });
                        AlertDialog alert = builder.create();
                        alert.show();
                    }else if(comando == Integer.parseInt(Comandi.GIAREGISTRATO)) {
                        builder.setMessage("Username già registrato. Effettua il Login!")
                                .setCancelable(false)
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        openActivityLogin();
                                    }
                                });
                        AlertDialog alert = builder.create();
                        alert.show();
                    }
                }
            }

        });


    }

    private void openActivityLogin(){
        Intent intentL = new Intent(this, LoginActivity.class);
        startActivity(intentL);
    }

    private void openActivityHome(){
        Intent intentH = new Intent(this, HomeActivity.class);
        startActivity(intentH);
    }

}