package com.example.lso_libreria;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import controller.Comandi;
import controller.Controller;
import enums.Genere;

public class CercaActivity extends AppCompatActivity {

    private final Genere[] items = Genere.values();
    private AutoCompleteTextView autoCompleteTextView;
    private EditText cerca_input;
    private Button vai;
    private Switch disponibili;
    private ImageButton back, carrello;
    private Controller controller;
    private String[] risposta;
    private int comando;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cerca);

        cerca_input = findViewById(R.id.cerca_input);
        vai = findViewById(R.id.vaiButton);
        back = findViewById(R.id.back_button);
        disponibili = findViewById(R.id.disponibili_switch);
        autoCompleteTextView = findViewById(R.id.auto_complete_txt);
        carrello = findViewById(R.id.carrello);


        ArrayAdapter<Genere> adapterItems = new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line, items);

        controller = Controller.getInstance();

        autoCompleteTextView.setAdapter(adapterItems);



        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityHome();
                finish();
            }
        });

        carrello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityCarrello();
            }
        });

        vai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String genere = autoCompleteTextView.getText().toString().trim();

                if(disponibili.isChecked() && !genere.isEmpty()){
                    String[] libriD = cercaLibroDisponibile();
                    String[] libriG = cercaLibroGenere(genere);
                    openActivityRisultatiRicerca(cercaLibriDisponibiliGenere(libriD,libriG));
                }
                else if(disponibili.isChecked())
                    openActivityRisultatiRicerca(cercaLibroDisponibile());
                else if(!genere.isEmpty())
                    openActivityRisultatiRicerca(cercaLibroGenere(genere));
                else
                    cercaLibro(cerca_input);


            }
        });


        autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(), "Genere Selezionato: " + item, Toast.LENGTH_SHORT).show();
            }
        });





    }


    private void openActivityHome(){
        Intent intentH = new Intent(this, HomeActivity.class);
        startActivity(intentH);
    }

    private void openActivityCarrello(){
        Intent intent = new Intent(this, CarrelloActivity.class);
        intent.putExtra("fromCerca",true);
        startActivity(intent);
    }

    private void openActivityRisultatiRicerca(String[] libri){
        Intent intentR = new Intent(this, RisultatiRicercaActivity.class);
        intentR.putExtra("Risultati", libri);
        startActivity(intentR);
    }

    private void cercaLibro(EditText cerca_input){
        AlertDialog.Builder builder = new AlertDialog.Builder(CercaActivity.this);

        try {
            risposta = controller.cercaLibri(cerca_input.getText().toString().trim());
            comando = Integer.parseInt(risposta[0].replace("Comando: ", "").trim());

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        if(comando == Integer.parseInt(Comandi.CERCA_LIBRO_OK)){
            String[] libri = Arrays.copyOfRange(risposta, 1 ,risposta.length);
            openActivityRisultatiRicerca(libri);

        }else if(comando == Integer.parseInt(Comandi.CERCA_LIBRO_ERR)){
            builder.setMessage("Errore durante La Ricerca. Riprova!")
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            cerca_input.setText("");
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
        }
    }

    private String[] cercaLibroGenere(String genere){
        AlertDialog.Builder builder = new AlertDialog.Builder(CercaActivity.this);

        try {
            risposta = controller.cercaLibriPerGenere(genere);
            comando = Integer.parseInt(risposta[0].replace("Comando: ", "").trim());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        if(comando == Integer.parseInt(Comandi.CERCA_LIBRO_GENERE_OK)){
            return Arrays.copyOfRange(risposta, 1 ,risposta.length);

        }else if(comando == Integer.parseInt(Comandi.CERCA_LIBRO_GENERE_ERR)){
            builder.setMessage("Errore durante la scelta del genere! Riprova!")
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
        }
        return new String[0];
    }

    private String[] cercaLibroDisponibile(){

        AlertDialog.Builder builder = new AlertDialog.Builder(CercaActivity.this);

        try {
            risposta = controller.cercaLibriDisponibili();
            comando = Integer.parseInt(risposta[0].replace("Comando: ", "").trim());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        if(comando == Integer.parseInt(Comandi.CERCA_LIBRO_DISPONIBILI_OK)){
            return Arrays.copyOfRange(risposta, 1 ,risposta.length);
        }else if (comando == Integer.parseInt(Comandi.CERCA_LIBRO_DISPONIBILI_ERR)){
            builder.setMessage("Errore durante L'inserimento del filtro Disponibili. Riprova!")
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
        }
        return new String[0];
    }

    private String[] cercaLibriDisponibiliGenere(String[] libriDisp, String[] libriGenere) {

        List<String> ris = new ArrayList<>();


        for (String libroDisp : libriDisp) {
            libroDisp = libroDisp.replace("Risultato ricerca libri disponibili:", "").trim();

            String[] libriDisponibili = libroDisp.split("ID:");

            for (String libroGenere : libriGenere) {
                libroGenere = libroGenere.replace("Risultato ricerca libri genere:", "").trim();

                String[] libriGenereSeparati = libroGenere.split("ID:");

                for (String libroDisponibile : libriDisponibili) {
                    libroDisponibile = libroDisponibile.trim();
                    for (String libro : libriGenereSeparati) {
                        libro = libro.trim();

                        if (libroDisponibile.equals(libro))
                            ris.add(libroDisponibile);
                    }
                }
            }
        }

        return ris.toArray(new String[0]);
    }







}
