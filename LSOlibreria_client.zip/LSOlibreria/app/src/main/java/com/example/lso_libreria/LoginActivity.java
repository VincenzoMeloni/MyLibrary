package com.example.lso_libreria;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import controller.Comandi;
import controller.Controller;
import model.Utente;

public class LoginActivity extends AppCompatActivity {

    private EditText username;
    private EditText password;
    private Button btnLogin;
    private TextView btnRegist;
    private Controller controller;
    private String[] risposta;
    private int comando;
    private Utente u;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.usernameEditText);
        password = findViewById(R.id.passwordEditText);
        btnLogin = findViewById(R.id.loginButton);
        btnRegist = findViewById(R.id.textView_registrati);

        controller = new Controller();

        btnRegist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityRegistrazione();
            }
        });


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();

                AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);

                if(user.length() == 0 || pass.length() == 0){
                    builder.setMessage("Bisogna riempire tutti i campi!")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                }
                            });
                    AlertDialog alert = builder.create();
                    alert.show();
                    username.setText("");
                    password.setText("");
                    return;
                }

                try {
                    risposta = controller.login(user,pass);
                    comando = Integer.parseInt(risposta[0].replace("Comando: ", "").trim());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }

                if(comando == Integer.parseInt(Comandi.LOGIN_OK)){
                    int userId = Integer.parseInt(risposta[2].replace("ID: ", "").trim());
                    int maxPrestiti = Integer.parseInt(risposta[3].replace("Max Prestiti: ", "").trim());
                    u = new Utente(userId,user,pass,maxPrestiti);
                    controller.getInstance().setUtente(u);
                    Toast.makeText(LoginActivity.this, "Login effettuato con Successo!", Toast.LENGTH_SHORT).show();
                    openActivityHome();
                }else if(comando == Integer.parseInt(Comandi.LOGIN_ERR)){
                    builder.setMessage("Errore durante il Login. Riprova!")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });
                    AlertDialog alert = builder.create();
                    alert.show();

                }else if(comando == Integer.parseInt(Comandi.LOGINNONTROVATO)){
                    builder.setMessage("Utente non trovato. Registrati!")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });
                    AlertDialog alert = builder.create();
                    alert.show();
                }


            }
        });





    }

    private void openActivityRegistrazione(){
        Intent intentR = new Intent(this, RegistrazioneActivity.class);
        startActivity(intentR);
    }

    private void openActivityHome(){
        Intent intentH = new Intent(this, HomeActivity.class);
        startActivity(intentH);
    }
}
