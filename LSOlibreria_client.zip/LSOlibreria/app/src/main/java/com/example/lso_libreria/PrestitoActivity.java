package com.example.lso_libreria;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import adapter.PrestitiAdapter;
import controller.Comandi;
import controller.Controller;
import model.Libro;
import model.Prestito;

public class PrestitoActivity extends AppCompatActivity {

    private ImageButton home,back;
    private TextView ris;
    private RecyclerView recyclerView;
    private String[] risultati;
    private int comando;
    private List<Prestito> prestiti = new ArrayList<>();
    private PrestitiAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceStates){
        super.onCreate(savedInstanceStates);
        setContentView(R.layout.activity_prestiti);

        home = findViewById(R.id.home);
        back = findViewById(R.id.back_button);
        ris = findViewById(R.id.ris);
        recyclerView = findViewById(R.id.prestiti_recycler_view);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        int id_utente = getIntent().getIntExtra("id_utente",0);

        String[] prestitiArray = caricaPrestiti();

        Map<Integer, Prestito> prestitoMap = new HashMap<>();

        if(prestitiArray != null && prestitiArray.length > 0){
            for(String prestitiData : prestitiArray){
                prestitiData = prestitiData.replace(" Risultati dei libri presi in prestito:","").trim();

                String[] prestitiSeparati = prestitiData.split("ID: ");

                for(String prestito : prestitiSeparati){
                    prestito = prestito.trim();

                    if(prestito.length() > 0){
                        String[] parts = prestito.split(",");

                        if(parts.length > 5){
                            String id_libro =  parts[0].replace("ID: ","").trim();
                            String titolo = parts[1].replace("Titolo: ", "").trim();
                            String autore = parts[2].replace("Autore: ", "").trim();
                            String genere = parts[3].replace("Genere: ","").trim();
                            String copie_prestito = parts[4].replace("Copie in prestito: ","").trim();
                            String data_scadenza =  parts[5].replace("Data di scadenza: ","").trim();

                            int id,copie;
                            try {
                                id = Integer.parseInt(id_libro);
                                copie = Integer.parseInt(copie_prestito);
                            }catch(NumberFormatException e){
                                id = 0;
                                copie = 0;
                            }

                            Date scadenza = null;
                            try {
                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS");
                                scadenza = sdf.parse(data_scadenza);
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }

                            Libro libro = new Libro(id,titolo,autore,copie,genere,copie);

                            Prestito prestitoP = prestitoMap.get(id);


                            if(prestitoP != null){
                                int nuoveCopie = prestitoP.getLibriInPrestito() + copie;
                                prestitoP.setLibriInPrestito(nuoveCopie);
                                prestitoP.setLibro(libro);
                                Controller.getInstance().setLibro(libro);
                                if (scadenza != null && scadenza.after(prestitoP.getData_scadenza()))
                                    prestitoP.setData_scadenza(scadenza);
                            }
                            else{
                                prestitoP = new Prestito(id_utente,new Date(),scadenza,false,copie,libro);
                                prestitoP.setLibro(libro);
                                Controller.getInstance().setLibro(libro);
                                prestitoMap.put(id, prestitoP);
                            }


                            prestiti.add(prestitoP);
                        }
                    }
                }
            }
            prestiti.clear();
            prestiti.addAll(prestitoMap.values());

            if(prestiti.size() > 0){
                adapter = new PrestitiAdapter(prestiti, new PrestitiAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(Prestito prestito) {
                        String dataFormattata = formattaData(prestito.getData_scadenza());
                        openDettagliLibro(dataFormattata,prestito.getLibriInPrestito(),prestito.getLibro().getId_libro());
                    }
                });
                recyclerView.setAdapter(adapter);
            }
            else
                ris.setText("Nessun Libro preso in prestito!");
        }
        else
            ris.setText("Nessun Libro preso in prestito!");

        mostraPopup();

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHomeActivity();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openProfiloActivity();
                finish();
            }
        });

    }

    private String[] caricaPrestiti(){

        AlertDialog.Builder builder = new AlertDialog.Builder(PrestitoActivity.this);

        try {
            risultati = Controller.getInstance().visualizzaPrestiti();
            comando = Integer.parseInt(risultati[0].replace("Comando: ", "").trim());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        if(comando == Integer.parseInt(Comandi.VISUALIZZA_PRESTITI_OK)){
            return Arrays.copyOfRange(risultati, 1 ,risultati.length);
        }else if(comando == Integer.parseInt(Comandi.VISUALIZZA_PRESTITI_ERR)){
            builder.setMessage("Errore durante La Visualizzazione dei Prestiti. Riprova più tardi")
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            openProfiloActivity();
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
        }

        return new String[0];
    }

    private String formattaData(Date data){
        if(data != null){
            SimpleDateFormat sdfOutput = new SimpleDateFormat("dd/MM/yyyy");
            String dataScadenzaFormattata = sdfOutput.format(data);
            return dataScadenzaFormattata;
        }
        return "";
    }

    private void mostraPopup(){
        boolean nonrestituito = false;
        Date currDate = new Date();



        for(Prestito p : prestiti){
            if(p.getData_scadenza().before(currDate)) {
                nonrestituito = true;
                break;
            }
        }

        if(nonrestituito){
            new AlertDialog.Builder(this)
                    .setTitle("Libri da Restituire")
                    .setMessage("I libri contrassegnati in rosso devono ancora essere Restituiti!")
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    })
                    .setCancelable(false)
                    .show();
        }
    }


    private void openProfiloActivity(){
        Intent intentP = new Intent(this, ProfiloActivity.class);
        startActivity(intentP);
    }

    private void openHomeActivity(){
        Intent intentH = new Intent(this, HomeActivity.class);
        startActivity(intentH);
    }

    private void openDettagliLibro(String data,int copiePrestito,int id_libro){
        Intent intentD = new Intent(this, DettagliLibroActivity.class);
        intentD.putExtra("dataScadenza",data);
        intentD.putExtra("fromPrestito",true);
        intentD.putExtra("copiePrestito",copiePrestito);
        intentD.putExtra("ID",id_libro);
        startActivity(intentD);
    }

}
