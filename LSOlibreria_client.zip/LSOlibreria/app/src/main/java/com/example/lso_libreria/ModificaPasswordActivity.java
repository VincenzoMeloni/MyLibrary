package com.example.lso_libreria;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import controller.Comandi;
import controller.Controller;
import model.Utente;

public class ModificaPasswordActivity extends AppCompatActivity {

    private ImageButton back;
    private EditText vpass,npass,cnpass;
    private Button modifica;
    private Utente u;
    private int comando;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modifica_password);

        back = findViewById(R.id.back_button);
        vpass = findViewById(R.id.vecchiapass);
        npass = findViewById(R.id.nuovapass);
        cnpass = findViewById(R.id.Confnuovapass);
        modifica = findViewById(R.id.modButton);

        u = Controller.getInstance().getUtente();


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openProfiloActivity();
                finish();
            }
        });

        modifica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String vecchia = vpass.getText().toString();
                String nuovaPass = npass.getText().toString();
                String confnuovaPass = cnpass.getText().toString();

                AlertDialog.Builder builder = new AlertDialog.Builder(ModificaPasswordActivity.this);

                if(vecchia.length() == 0 || nuovaPass.length() == 0 || confnuovaPass.length() == 0){
                    builder.setMessage("Bisogna riempire tutti i campi!")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                }
                            });
                    AlertDialog alert = builder.create();
                    alert.show();
                    vpass.setText("");
                    npass.setText("");
                    cnpass.setText("");
                    return;
                }
                else if(!nuovaPass.equals(confnuovaPass)){
                    builder.setMessage("Le password non corrispondono, riprova")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                }
                            });
                    AlertDialog alert = builder.create();
                    alert.show();
                    npass.setText("");
                    cnpass.setText("");
                }
                else{
                    try {
                        comando = Controller.getInstance().aggiornaPassword(vecchia,nuovaPass);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }

                    if(comando == Integer.parseInt(Comandi.MODPASS_OK)){
                        builder.setMessage("Password Modificata con Successo!")
                                .setCancelable(false)
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        openProfiloActivity();
                                    }
                                });
                        AlertDialog alert = builder.create();
                        alert.show();
                    }
                    else if(comando == Integer.parseInt(Comandi.MODPASS_ERR)){
                        builder.setMessage("Errore durante la modifica della Password! Riprova!")
                                .setCancelable(false)
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                    }
                                });
                        AlertDialog alert = builder.create();
                        alert.show();
                        vpass.setText("");
                        npass.setText("");
                        cnpass.setText("");
                    }else if(comando == Integer.parseInt(Comandi.VECCHIAPASSWORDERRATA)){
                        builder.setMessage("Attenzione! Vecchia password non corretta! Riprova!")
                                .setCancelable(false)
                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                    }
                                });
                        AlertDialog alert = builder.create();
                        alert.show();
                        vpass.setText("");
                        npass.setText("");
                        cnpass.setText("");
                    }
                }

            }
        });

    }

    private void openProfiloActivity(){
        Intent intentP = new Intent(this, ProfiloActivity.class);
        startActivity(intentP);
    }
}
