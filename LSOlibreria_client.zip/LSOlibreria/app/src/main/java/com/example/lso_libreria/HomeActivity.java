package com.example.lso_libreria;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import controller.Controller;


public class HomeActivity extends AppCompatActivity {
    private ImageButton cerca;
    private ImageButton carrello;
    private ImageButton profilo;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        cerca = findViewById(R.id.cerca);
        carrello = findViewById(R.id.carrello);
        profilo = findViewById(R.id.profilo);

        cerca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityCerca();
            }
        });

        carrello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityCarrello();
            }
        });


        profilo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityProfilo();
            }
        });


    }


    private void openActivityCerca(){
        Intent intentC = new Intent(this, CercaActivity.class);
        startActivity(intentC);
    }

    private void openActivityCarrello(){
        Intent intent = new Intent(this, CarrelloActivity.class);
        startActivity(intent);
    }

    private void openActivityProfilo(){
        Intent intentP = new Intent(this, ProfiloActivity.class);
        startActivity(intentP);
    }



}
