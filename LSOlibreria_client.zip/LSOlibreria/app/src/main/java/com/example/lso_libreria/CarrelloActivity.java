package com.example.lso_libreria;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import model.Libro;

public class CarrelloActivity extends AppCompatActivity {

    private ImageButton back,home;
    private Button rimuovi,checkout;
    private List<Libro> libri;
    private boolean fromCerca,fromRisultati,fromDettagli,fromProfilo;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrello);

        back = findViewById(R.id.back_button);
        rimuovi = findViewById(R.id.remove_button);
        checkout = findViewById(R.id.checkout_button);
        home = findViewById(R.id.home);

        fromCerca = getIntent().getBooleanExtra("fromCerca",false);
        fromRisultati = getIntent().getBooleanExtra("fromRisultati",false);
        fromDettagli = getIntent().getBooleanExtra("fromDettagli",false);
        String[] libri = getIntent().getStringArrayExtra("Risultati");
        int id_libro = getIntent().getIntExtra("ID",0);
        fromProfilo = getIntent().getBooleanExtra("fromProfilo",false);

        if(!fromCerca && !fromRisultati && !fromDettagli && !fromProfilo)
            home.setVisibility(View.GONE);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityHome();
                finish();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(fromCerca)
                    openActivityCerca();
                else if(fromRisultati)
                    openActivityRisultatiRicerca(libri);
                else if(fromDettagli)
                    openDettagliLibroActivity(libri,id_libro);
                else if(fromProfilo)
                    openActivityProfilo();
                else
                openActivityHome();
            }
        });


    }


    private void openActivityHome(){
        Intent intentH = new Intent(this, HomeActivity.class);
        startActivity(intentH);
    }

    private void openActivityCerca(){
        Intent intentC = new Intent(this, CercaActivity.class);
        startActivity(intentC);
    }

    private void openActivityRisultatiRicerca(String[] libri){
        Intent intentR = new Intent(this, RisultatiRicercaActivity.class);
        intentR.putExtra("Risultati", libri);
        startActivity(intentR);
    }

    private void openDettagliLibroActivity(String[] libri,int id){
        Intent intentD = new Intent(this, DettagliLibroActivity.class);
        intentD.putExtra("ID",id);
        intentD.putExtra("Risultati", libri);
        startActivity(intentD);
    }

    private void openActivityProfilo(){
        Intent intentP = new Intent(this, ProfiloActivity.class);
        startActivity(intentP);
    }
}
