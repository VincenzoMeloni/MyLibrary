package com.example.lso_libreria;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import adapter.RisultatiAdapter;
import controller.Comandi;
import controller.Controller;
import model.Libro;
import model.Utente;

public class CarrelloActivity extends AppCompatActivity {

    private ImageButton back,home;
    private Button rimuovi,checkout;
    private List<Libro> libri;
    private RecyclerView recyclerView;
    private RisultatiAdapter adapter;
    private String[] risultati;
    private int comando;
    private TextView ris;
    private boolean fromCerca,fromRisultati,fromDettagli,fromProfilo;
    private AlertDialog.Builder builder;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrello);

        back = findViewById(R.id.back_button);
        rimuovi = findViewById(R.id.remove_button);
        checkout = findViewById(R.id.checkout_button);
        home = findViewById(R.id.home);
        recyclerView = findViewById(R.id.risultati_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        ris = findViewById(R.id.ris);
        checkout = findViewById(R.id.checkout_button);

        libri = new ArrayList<>();

        builder = new AlertDialog.Builder(CarrelloActivity.this);

        fromCerca = getIntent().getBooleanExtra("fromCerca",false);
        fromRisultati = getIntent().getBooleanExtra("fromRisultati",false);
        fromDettagli = getIntent().getBooleanExtra("fromDettagli",false);
        String[] libro = getIntent().getStringArrayExtra("Risultati");
        int libro_id = getIntent().getIntExtra("ID",0);
        fromProfilo = getIntent().getBooleanExtra("fromProfilo",false);

        String[] libriArray = caricaCarrello();

        if (libriArray != null) {
            for (String libroData : libriArray) {

                libroData = libroData.replace("Risultato ricerca libri:", "").trim();

                String[] libriSeparati = libroData.split("ID: ");


                for (String libroc : libriSeparati) {
                    libroc = libroc.trim();

                    if (libroc.length() > 0) {
                        String[] parts = libroc.split(",");
                        Log.d("Parts", Arrays.toString(parts));

                        if (parts.length > 4) {
                            String id_libro = parts[0].replace("ID: ","").trim();
                            String titolo = parts[1].replace("Titolo: ", "").trim();
                            String autore = parts[2].replace("Autore: ", "").trim();
                            String copieString = parts[3].replace("Copie disponibili: ", "").trim();
                            String genere = parts[4].replace("Genere: ","").trim();


                            int copieDisponibili,id;
                            try {
                                copieDisponibili = Integer.parseInt(copieString);
                                id = Integer.parseInt(id_libro);
                            } catch (NumberFormatException e) {
                                copieDisponibili = 0;
                                id = 0;
                            }

                            int quantita = Controller.getInstance().getQuantita(id);

                            libri.add(new Libro(id,titolo, autore, copieDisponibili,genere,quantita));
                        }
                    }
                }
            }

            if (libri.size() > 0) {
                adapter = new RisultatiAdapter(libri, new RisultatiAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(Libro libro) {
                        Controller.getInstance().setLibro(libro);

                    }
                },true);
                recyclerView.setAdapter(adapter);
            } else {
                ris.setText("Carrello vuoto. Aggiungi qualche libro!");
            }
        } else {
            ris.setText("Carrello vuoto. Aggiungi qualche libro!");
        }



        if(!fromCerca && !fromRisultati && !fromDettagli && !fromProfilo)
            home.setVisibility(View.GONE);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityHome();
                finish();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(fromCerca)
                    openActivityCerca();
                else if(fromRisultati)
                    openActivityRisultatiRicerca(libro);
                else if(fromDettagli)
                    openDettagliLibroActivity(libro,libro_id);
                else if(fromProfilo)
                    openActivityProfilo();
                else
                openActivityHome();
            }
        });

        rimuovi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Libro> selezionati = adapter.getSelectedItems();

                if(!selezionati.isEmpty()) {
                    builder.setMessage("Sei sicuro di voler rimuovere questi libri dal carrello?")
                            .setCancelable(false)
                            .setPositiveButton("Sì", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    rimuoviLibri(selezionati);
                                }
                            })
                            .setNegativeButton("No", null)
                            .show();
                }
                else
                    Toast.makeText(CarrelloActivity.this, "Nessun libro selezionato per la rimozione", Toast.LENGTH_SHORT).show();

            }
        });


        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.setMessage("Effettuare il checkout?")
                        .setCancelable(false)
                        .setPositiveButton("Sì", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                doCheckout();
                            }
                        })
                        .setNegativeButton("No", null)
                        .show();
            }
        });


    }

    private String[] caricaCarrello(){
        try {
            risultati = Controller.getInstance().visualizzaCarrello();
            comando = Integer.parseInt(risultati[0].replace("Comando: ", "").trim());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        if(comando == Integer.parseInt(Comandi.VISUALIZZA_CARRELLO_OK)){
            return Arrays.copyOfRange(risultati, 1 ,risultati.length);
        }else if(comando == Integer.parseInt(Comandi.VISUALIZZA_CARRELLO_ERR)){
            builder.setMessage("Errore durante La Visualizzazione del carrello. Riprova più tardi")
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            openActivityHome();
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
        }
        return new String[0];
    }

    private void rimuoviLibri(List<Libro> libriDaRimuovere){

        List<Libro> rimossiConSuccesso = new ArrayList<>();

        for(Libro libro : libriDaRimuovere){
            try {
                comando = Controller.getInstance().remCarrello(libro.getId_libro());
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            if(comando == Integer.parseInt(Comandi.REM_CARRELLO_OK)){
                rimossiConSuccesso.add(libro);
                libri.removeAll(rimossiConSuccesso);
                adapter.notifyDataSetChanged();
                Toast.makeText(CarrelloActivity.this, "Libri rimossi dal carrello con successo", Toast.LENGTH_SHORT).show();
            }
            else if(comando == Integer.parseInt(Comandi.REM_CARRELLO_ERR)){
                builder.setMessage("Errore durante la rimozione. Riprova.")
                        .setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();
            }

        }

    }

    private void doCheckout(){

        try {
            risultati = Controller.getInstance().checkout();
            comando = Integer.parseInt(risultati[0].replace("Comando: ", "").trim());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        if(comando == Integer.parseInt(Comandi.CHECKOUT_OK)){
            Toast.makeText(CarrelloActivity.this, "Checkout effettuato con Successo!", Toast.LENGTH_SHORT).show();
            int maxPrestiti = Integer.parseInt(risultati[2].replace("Max Prestiti aggiornati:","").trim());

            Utente u = Controller.getInstance().getUtente();

            if(u != null){
                u.setMax_prestiti(maxPrestiti);
                Controller.getInstance().setUtente(u);
            }
            adapter.notifyDataSetChanged();

            openActivityHome();
        }else if(comando == Integer.parseInt(Comandi.CHECKOUT_ERR)){
            builder.setMessage("Errore durante il Checkout. Riprova.")
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();

        }else if(comando == Integer.parseInt(Comandi.MAXPRESTITI_ERR)){
            builder.setMessage("Errore durante il Checkout! Hai superato il limite massimo di libri da poter prendere in prestito!")
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
        }else if(comando == Integer.parseInt(Comandi.LIBRONONDISPONIBILE)){
            builder.setMessage("Errore! Qualche libro nel carrello ha terminato le copie disponibili!")
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            openActivityHome();
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
        }

    }


    private void openActivityHome(){
        Intent intentH = new Intent(this, HomeActivity.class);
        startActivity(intentH);
    }

    private void openActivityCerca(){
        Intent intentC = new Intent(this, CercaActivity.class);
        startActivity(intentC);
    }

    private void openActivityRisultatiRicerca(String[] libri){
        Intent intentR = new Intent(this, RisultatiRicercaActivity.class);
        intentR.putExtra("Risultati", libri);
        startActivity(intentR);
    }

    private void openDettagliLibroActivity(String[] libri,int id){
        Intent intentD = new Intent(this, DettagliLibroActivity.class);
        intentD.putExtra("ID",id);
        intentD.putExtra("Risultati", libri);
        startActivity(intentD);
    }

    private void openActivityProfilo(){
        Intent intentP = new Intent(this, ProfiloActivity.class);
        startActivity(intentP);
    }
}
