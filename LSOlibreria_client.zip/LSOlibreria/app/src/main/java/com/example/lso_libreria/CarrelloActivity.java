package com.example.lso_libreria;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import adapter.RisultatiAdapter;
import controller.Comandi;
import controller.Controller;
import model.Libro;
import model.Utente;

public class CarrelloActivity extends AppCompatActivity {

    private ImageButton back,home;
    private Button rimuovi,checkout;
    private List<Libro> libri;
    private RecyclerView recyclerView;
    private RisultatiAdapter adapter;
    private String[] risultati;
    private int comando;
    private TextView ris;
    private boolean fromCerca,fromRisultati,fromDettagli,fromProfilo;
    private AlertDialog.Builder builder;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrello);

        back = findViewById(R.id.back_button);
        rimuovi = findViewById(R.id.remove_button);
        checkout = findViewById(R.id.checkout_button);
        home = findViewById(R.id.home);
        recyclerView = findViewById(R.id.risultati_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        ris = findViewById(R.id.ris);
        checkout = findViewById(R.id.checkout_button);

        libri = new ArrayList<>();

        builder = new AlertDialog.Builder(CarrelloActivity.this);

        fromCerca = getIntent().getBooleanExtra("fromCerca",false);
        fromRisultati = getIntent().getBooleanExtra("fromRisultati",false);
        fromDettagli = getIntent().getBooleanExtra("fromDettagli",false);
        String[] libro = getIntent().getStringArrayExtra("Risultati");
        int libro_id = getIntent().getIntExtra("ID",0);
        fromProfilo = getIntent().getBooleanExtra("fromProfilo",false);

        String[] libriArray = caricaCarrello();

        if (libriArray != null && libriArray.length > 0) {
            for (String libroData : libriArray) {

                libroData = libroData.replace(" Risultati dei libri nel carrello:", "").trim();

                String[] libriSeparati = libroData.split("ID: ");


                for (String libroc : libriSeparati) {
                    libroc = libroc.trim();

                    if (libroc.length() > 0) {
                        String[] parts = libroc.split(",");

                        if (parts.length > 4) {
                            String id_libro = parts[0].replace("ID: ","").trim();
                            String titolo = parts[1].replace("Titolo: ", "").trim();
                            String autore = parts[2].replace("Autore: ", "").trim();
                            String copieString = parts[3].replace("Copie disponibili: ", "").trim();
                            String genere = parts[4].replace("Genere: ","").trim();
                            String num = parts[5].replace("Quantita: ", "").trim();

                            int copieDisponibili,id,quantita;
                            try {
                                copieDisponibili = Integer.parseInt(copieString);
                                id = Integer.parseInt(id_libro);
                                quantita = Integer.parseInt(num);
                            } catch (NumberFormatException e) {
                                copieDisponibili = 0;
                                id = 0;
                                quantita = 0;
                            }

                            Controller.getInstance().aggiornaQuantitaLibro(id,quantita);

                            libri.add(new Libro(id,titolo, autore, copieDisponibili,genere,quantita));
                        }
                    }
                }
            }

            if (libri.size() > 0) {
                adapter = new RisultatiAdapter(libri, new RisultatiAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(Libro libro) {
                        Controller.getInstance().setLibro(libro);

                    }
                },true);
                recyclerView.setAdapter(adapter);
            } else
                ris.setText("Carrello vuoto. Aggiungi qualche libro!");

        } else
            ris.setText("Carrello vuoto. Aggiungi qualche libro!");




        if(!fromCerca && !fromRisultati && !fromDettagli && !fromProfilo)
            home.setVisibility(View.GONE);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityHome();
                finish();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(fromCerca)
                    openActivityCerca();
                else if(fromRisultati)
                    openActivityRisultatiRicerca(libro);
                else if(fromDettagli)
                    openDettagliLibroActivity(libro,libro_id);
                else if(fromProfilo)
                    openActivityProfilo();
                else
                openActivityHome();
            }
        });

        rimuovi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (adapter == null || adapter.getItemCount() == 0) {
                    Toast.makeText(CarrelloActivity.this, "Il carrello è vuoto. Aggiungi qualche libro!", Toast.LENGTH_SHORT).show();
                    return;
                }
                List<Libro> selezionati = adapter.getSelectedItems();

                if(!selezionati.isEmpty()) {
                   builder.setMessage("Sei sicuro di voler rimuovere questi libri dal carrello?")
                            .setCancelable(false)
                            .setPositiveButton("Sì", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    rimuoviLibri(selezionati);
                                }
                            })
                            .setNegativeButton("No", null)
                            .show();

                    //showRemoveDialog(selezionati);

                }
                else
                    Toast.makeText(CarrelloActivity.this, "Nessun libro selezionato per la rimozione", Toast.LENGTH_SHORT).show();

            }
        });


        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (adapter == null || adapter.getItemCount() == 0) {
                    Toast.makeText(CarrelloActivity.this, "Il carrello è vuoto. Aggiungi qualche libro!", Toast.LENGTH_SHORT).show();
                    return;
                }

                builder.setMessage("Effettuare il checkout?")
                        .setCancelable(false)
                        .setPositiveButton("Sì", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                doCheckout();
                            }
                        })
                        .setNegativeButton("No", null)
                        .show();
            }
        });


    }

    private String[] caricaCarrello(){
        try {
            risultati = Controller.getInstance().visualizzaCarrello();
            comando = Integer.parseInt(risultati[0].replace("Comando: ", "").trim());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        if(comando == Integer.parseInt(Comandi.VISUALIZZA_CARRELLO_OK)){
            return Arrays.copyOfRange(risultati, 1 ,risultati.length);
        }else if(comando == Integer.parseInt(Comandi.VISUALIZZA_CARRELLO_ERR)){
            builder.setMessage("Errore durante La Visualizzazione del carrello. Riprova più tardi")
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            openActivityHome();
                        }
                    });
            AlertDialog alert = builder.create();
            alert.show();
        }
        return new String[0];
    }

    private void rimuoviLibri(List<Libro> libriDaRimuovere){

        List<Libro> rimossiConSuccesso = new ArrayList<>();

        for(Libro libro : libriDaRimuovere){
            try {
                comando = Controller.getInstance().remCarrello(libro.getId_libro());
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            if(comando == Integer.parseInt(Comandi.REM_CARRELLO_OK)){
                rimossiConSuccesso.add(libro);
                libri.removeAll(rimossiConSuccesso);
                adapter.notifyDataSetChanged();
                Controller.getInstance().aggiornaQuantitaLibro(libro.getId_libro(),0);
                Toast.makeText(CarrelloActivity.this, "Libri rimossi dal carrello con successo", Toast.LENGTH_SHORT).show();
            }
            else if(comando == Integer.parseInt(Comandi.REM_CARRELLO_ERR)){
                builder.setMessage("Errore durante la rimozione. Riprova.")
                        .setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();
            }

        }

    }

   /* private void showRemoveDialog(List<Libro> libriDaRimuovere) {
        AlertDialog.Builder builder = new AlertDialog.Builder(CarrelloActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.activity_popup_quantita, null);
        builder.setView(dialogView);

        Button btnIncrement = dialogView.findViewById(R.id.btn_increment);
        Button btnDecrement = dialogView.findViewById(R.id.btn_decrement);
        TextView tvQuantity = dialogView.findViewById(R.id.tv_quantity);
        Button btnRimuovi = dialogView.findViewById(R.id.btn_aggiungi);
        btnRimuovi.setText("Rimuovi");
        Button btnAnnulla = dialogView.findViewById(R.id.btn_annulla);

        int id_libro = 0;

        for(Libro libro : libriDaRimuovere){
            if(libro != null)
            id_libro = libro.getId_libro();
        }

        int currentQuantity = 1;
        tvQuantity.setText(String.valueOf(currentQuantity));

        int disponibiliNelCarrello = Controller.getInstance().getQuantita(id_libro);

        if (disponibiliNelCarrello <= 0) {
            btnIncrement.setEnabled(false);
        }

        btnIncrement.setOnClickListener(v -> {
            int newQuantity = Integer.parseInt(tvQuantity.getText().toString());
            if (newQuantity < disponibiliNelCarrello) {
                newQuantity++;
                tvQuantity.setText(String.valueOf(newQuantity));
            }
            if (newQuantity == disponibiliNelCarrello) {
                btnIncrement.setEnabled(false);
            }
            btnDecrement.setEnabled(newQuantity > 1);
        });

        btnDecrement.setOnClickListener(v -> {
            int newQuantity = Integer.parseInt(tvQuantity.getText().toString());
            if (newQuantity > 1) {
                newQuantity--;
                tvQuantity.setText(String.valueOf(newQuantity));
            }
            if (newQuantity == 1) {
                btnDecrement.setEnabled(false);
            }
            btnIncrement.setEnabled(true);
        });

        AlertDialog dialog = builder.create();
        dialog.show();

        btnDecrement.setEnabled(false);

        int finalId_libro = id_libro;
        btnRimuovi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedQuantity = Integer.parseInt(tvQuantity.getText().toString());

                if (selectedQuantity > disponibiliNelCarrello) {
                    Toast.makeText(CarrelloActivity.this,
                            "Errore: non puoi rimuovere più copie di quelle disponibili nel carrello!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    for (int i = 0; i < selectedQuantity; i++) {
                        int comando = Controller.getInstance().remCarrello(finalId_libro);
                        if (comando != Integer.parseInt(Comandi.REM_CARRELLO_OK)) {
                            Toast.makeText(CarrelloActivity.this,
                                    "Errore nella rimozione di una copia dal carrello!", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                    int nuoveCopieDisponibili = disponibiliNelCarrello + selectedQuantity;
                    Controller.getInstance().aggiornaQuantitaLibro(finalId_libro, nuoveCopieDisponibili);
                    Toast.makeText(CarrelloActivity.this,
                            "Rimosse " + selectedQuantity + " copie dal carrello con successo!",
                            Toast.LENGTH_SHORT).show();
                    adapter.notifyDataSetChanged();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                dialog.dismiss();
            }
        });

        btnAnnulla.setOnClickListener(v -> dialog.dismiss());
    }*/


    private void doCheckout(){

        try {
            risultati = Controller.getInstance().checkout();
            comando = Integer.parseInt(risultati[0].replace("Comando: ", "").trim());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        if(comando == Integer.parseInt(Comandi.CHECKOUT_OK)){
            Toast.makeText(CarrelloActivity.this, "Checkout effettuato con Successo!", Toast.LENGTH_SHORT).show();
            int maxPrestiti = Integer.parseInt(risultati[2].replace("Max Prestiti aggiornati:","").trim());

            Utente u = Controller.getInstance().getUtente();

            if(u != null){
                u.setMax_prestiti(maxPrestiti);
                Controller.getInstance().setUtente(u);
            }
            adapter.notifyDataSetChanged();

            openActivityHome();
        }else if(comando == Integer.parseInt(Comandi.CHECKOUT_ERR)){
            builder.setMessage("Errore durante il Checkout. Riprova.")
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    }).setNegativeButton("",null);
            AlertDialog alert = builder.create();
            alert.show();

        }else if(comando == Integer.parseInt(Comandi.MAXPRESTITI_ERR)){
            builder.setMessage("Errore durante il Checkout! Hai superato il limite massimo di libri da poter prendere in prestito!")
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    }).setNegativeButton("",null);
            AlertDialog alert = builder.create();
            alert.show();
        }else if(comando == Integer.parseInt(Comandi.LIBRONONDISPONIBILE)){
            builder.setMessage("Errore! Qualche libro nel carrello ha terminato le copie disponibili!")
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            openActivityHome();
                        }
                    }).setNegativeButton("",null);
            AlertDialog alert = builder.create();
            alert.show();
        }

    }


    private void openActivityHome(){
        Intent intentH = new Intent(this, HomeActivity.class);
        startActivity(intentH);
    }

    private void openActivityCerca(){
        Intent intentC = new Intent(this, CercaActivity.class);
        startActivity(intentC);
    }

    private void openActivityRisultatiRicerca(String[] libri){
        Intent intentR = new Intent(this, RisultatiRicercaActivity.class);
        intentR.putExtra("Risultati", libri);
        startActivity(intentR);
    }

    private void openDettagliLibroActivity(String[] libri,int id){
        Intent intentD = new Intent(this, DettagliLibroActivity.class);
        intentD.putExtra("ID",id);
        intentD.putExtra("Risultati", libri);
        startActivity(intentD);
    }

    private void openActivityProfilo(){
        Intent intentP = new Intent(this, ProfiloActivity.class);
        startActivity(intentP);
    }
}
