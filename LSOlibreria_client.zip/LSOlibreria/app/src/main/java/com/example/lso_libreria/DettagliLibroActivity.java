package com.example.lso_libreria;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import controller.Comandi;
import controller.Controller;
import model.Libro;

public class DettagliLibroActivity extends AppCompatActivity {

    private ImageButton back,carrello,home;
    private TextView titolo,autore,genere,copie,scadenza;
    private Libro libro;
    private Button addCarrello;
    private String[] risposta;
    private int comando;
    private boolean fromPrestito;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dettagli_libro);

        back = findViewById(R.id.back_button);
        carrello = findViewById(R.id.carrello);
        home = findViewById(R.id.home);
        titolo = findViewById(R.id.titolo);
        autore = findViewById(R.id.autore);
        genere = findViewById(R.id.Genere);
        copie = findViewById(R.id.Copie);
        addCarrello = findViewById(R.id.AddCarrelloButton);
        scadenza = findViewById(R.id.Scadenza);

        int id_libro = getIntent().getIntExtra("ID", 0);
        String[] libri = getIntent().getStringArrayExtra("Risultati");
        fromPrestito = getIntent().getBooleanExtra("fromPrestito",false);
        String dataScadenza = getIntent().getStringExtra("dataScadenza");
        int copiePrestito = getIntent().getIntExtra("copiePrestito",0);

        libro = Controller.getInstance().getLibroById(id_libro);

        titolo.setText(libro.getTitolo());
        autore.setText(libro.getAutore());
        genere.setText(libro.getGenere());
        if(!fromPrestito) {
            copie.setText("Copie Disponibili: " + libro.getNum_copie_disponibili());
            scadenza.setVisibility(View.GONE);
        }else {
            copie.setText("Copie Prese in Prestito: " + copiePrestito);
            scadenza.setText("Data di Scadenza: "+ dataScadenza);
            addCarrello.setVisibility(View.GONE);
            carrello.setVisibility(View.GONE);
        }

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!fromPrestito)
                openActivityRisultatiRicerca(libri);
                else
                    openActivityPrestito();

            }
        });

        carrello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityCarrello(libri,id_libro);
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openHomeActivity();
            }
        });

        addCarrello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int maxCopie = libro.getNum_copie_disponibili();
                showQuantityDialog(id_libro,maxCopie);

            }
        });

    }

    private void showQuantityDialog(int id_libro,int maxCopie) {
        AlertDialog.Builder builder = new AlertDialog.Builder(DettagliLibroActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.activity_popup_quantita, null);
        builder.setView(dialogView);

         Button btnIncrement = dialogView.findViewById(R.id.btn_increment);
         Button btnDecrement = dialogView.findViewById(R.id.btn_decrement);
         TextView tvQuantity = dialogView.findViewById(R.id.tv_quantity);
         Button btnAggiungi = dialogView.findViewById(R.id.btn_aggiungi);
         Button btnAnnulla = dialogView.findViewById(R.id.btn_annulla);

        int currentQuantity = 1;
        tvQuantity.setText(String.valueOf(currentQuantity));

        int disponibilita = maxCopie - Controller.getInstance().getQuantita(id_libro);

        if(disponibilita <= 0)
            btnIncrement.setEnabled(false);

        btnIncrement.setOnClickListener(v -> {
            int newQuantity = Integer.parseInt(tvQuantity.getText().toString());
            if (newQuantity < disponibilita) {
                newQuantity++;
                tvQuantity.setText(String.valueOf(newQuantity));
            }
            if (newQuantity == disponibilita) {
                btnIncrement.setEnabled(false);
            }
            btnDecrement.setEnabled(newQuantity > 1);
        });

        btnDecrement.setOnClickListener(v -> {
            int newQuantity = Integer.parseInt(tvQuantity.getText().toString());
            if (newQuantity > 1) {
                newQuantity--;
                tvQuantity.setText(String.valueOf(newQuantity));
            }
            if (newQuantity == 1)
                btnDecrement.setEnabled(false);

            btnIncrement.setEnabled(true);
        });

        AlertDialog dialog = builder.create();
        dialog.show();

        btnDecrement.setEnabled(false);

        btnAggiungi.setOnClickListener(v -> {
            int selectedQuantity = Integer.parseInt(tvQuantity.getText().toString());

            if (selectedQuantity > disponibilita) {
                Toast.makeText(DettagliLibroActivity.this,
                        "Non puoi aggiungere più copie di quelle disponibili!", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                for (int i = 0; i < selectedQuantity; i++) {
                     risposta = Controller.getInstance().addCarrello(id_libro);
                     comando = Integer.parseInt(risposta[0].replace("Comando: ", "").trim());

                    if (comando == Integer.parseInt(Comandi.ADD_CARRELLO_ERR)) {
                        Toast.makeText(DettagliLibroActivity.this,
                                "Errore nell'aggiunta di una copia al carrello!", Toast.LENGTH_SHORT).show();
                        return;
                    } else if (comando == Integer.parseInt(Comandi.ADD_CARRELLO_OK)) {
                         int quantita = Integer.parseInt(risposta[3].replace("Quantita: ", "").trim());
                         Controller.getInstance().aggiornaQuantitaLibro(id_libro,quantita);
                    }
                }
                Toast.makeText(DettagliLibroActivity.this,
                        "Aggiunto al carrello con successo!", Toast.LENGTH_SHORT).show();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            dialog.dismiss();
        });


        btnAnnulla.setOnClickListener(v -> dialog.dismiss());


    }



    protected void openActivityCarrello(String[]libri,int id){
        Intent intent = new Intent(this, CarrelloActivity.class);
        intent.putExtra("fromDettagli",true);
        intent.putExtra("ID",id);
        intent.putExtra("Risultati", libri);
        startActivity(intent);
    }

    private void openHomeActivity(){
        Intent intentH = new Intent(this, HomeActivity.class);
        startActivity(intentH);
    }

    private void openActivityRisultatiRicerca(String[] libri){
        Intent intentR = new Intent(this, RisultatiRicercaActivity.class);
        intentR.putExtra("Risultati", libri);
        startActivity(intentR);
    }

    private void openActivityPrestito(){
        Intent intentP = new Intent(this,PrestitoActivity.class);
        startActivity(intentP);
    }

}
