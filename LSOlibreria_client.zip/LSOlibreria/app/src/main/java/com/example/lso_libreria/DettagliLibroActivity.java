package com.example.lso_libreria;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import controller.Comandi;
import controller.Controller;
import model.Libro;

public class DettagliLibroActivity extends AppCompatActivity {

    private ImageButton back,carrello,home;
    private TextView titolo,autore,genere,copie;
    private Libro libro;
    private Button addCarrello;
    private int comando;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dettagli_libro);

        back = findViewById(R.id.back_button);
        carrello = findViewById(R.id.carrello);
        home = findViewById(R.id.home);
        titolo = findViewById(R.id.titolo);
        autore = findViewById(R.id.autore);
        genere = findViewById(R.id.Genere);
        copie = findViewById(R.id.Copie);
        addCarrello = findViewById(R.id.AddCarrelloButton);

        int id_libro = getIntent().getIntExtra("ID", 0);
        String[] libri = getIntent().getStringArrayExtra("Risultati");

        libro = Controller.getInstance().getLibroById(id_libro);

        titolo.setText(libro.getTitolo());
        autore.setText(libro.getAutore());
        genere.setText(libro.getGenere());
        copie.setText("Copie Disponibili: " + libro.getNum_copie_disponibili());

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityRisultatiRicerca(libri);
            }
        });

        carrello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityCarrello(libri,id_libro);
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openHomeActivity();
            }
        });

        addCarrello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(DettagliLibroActivity.this);
                try {
                    comando = Controller.getInstance().addCarrello(id_libro);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }

                if(comando == Integer.parseInt(Comandi.ADD_CARRELLO_OK)){
                    builder.setMessage("Libro aggiunto al carrello con Successo!")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });
                    AlertDialog alert = builder.create();
                    alert.show();
                }else if(comando == Integer.parseInt(Comandi.ADD_CARRELLO_ERR)){
                    builder.setMessage("Errore durante l'aggiunta al carrello! Riprova.")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });
                    AlertDialog alert = builder.create();
                    alert.show();

                }else if(comando == Integer.parseInt(Comandi.LIBRODUPLICATO)){
                    builder.setMessage("Il libro è già nel carrello!")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {

                                }
                            });
                    AlertDialog alert = builder.create();
                    alert.show();
                }
            }
        });

    }

    protected void openActivityCarrello(String[]libri,int id){
        Intent intent = new Intent(this, CarrelloActivity.class);
        intent.putExtra("fromDettagli",true);
        intent.putExtra("ID",id);
        intent.putExtra("Risultati", libri);
        startActivity(intent);
    }

    private void openHomeActivity(){
        Intent intentH = new Intent(this, HomeActivity.class);
        startActivity(intentH);
    }

    private void openActivityRisultatiRicerca(String[] libri){
        Intent intentR = new Intent(this, RisultatiRicercaActivity.class);
        intentR.putExtra("Risultati", libri);
        startActivity(intentR);
    }

}
