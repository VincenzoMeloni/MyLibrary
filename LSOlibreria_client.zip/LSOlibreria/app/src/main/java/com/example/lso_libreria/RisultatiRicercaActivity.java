package com.example.lso_libreria;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import adapter.RisultatiAdapter;
import controller.Controller;
import enums.Genere;
import model.Libro;

public class RisultatiRicercaActivity extends AppCompatActivity {

    private ImageButton back,carrello,home;
    private List<Libro> libri;
    private RecyclerView recyclerView;
    private RisultatiAdapter adapter;
    private TextView ris;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_risultati_ricerca);

        back = findViewById(R.id.back_button);
        carrello = findViewById(R.id.carrello);
        home = findViewById(R.id.home);
        recyclerView = findViewById(R.id.risultati_recycler_view);
        ris = findViewById(R.id.ris);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        libri = new ArrayList<>();

        String[] libriArray = getIntent().getStringArrayExtra("Risultati");

        if (libriArray != null) {
            for (String libroData : libriArray) {

                libroData = libroData.replace("Risultato ricerca libri:", "").trim();

                String[] libriSeparati = libroData.split("ID: ");


                for (String libro : libriSeparati) {
                    libro = libro.trim();

                    if (libro.length() > 0) {
                        String[] parts = libro.split(",");
                        Log.d("Parts", Arrays.toString(parts));

                        if (parts.length > 4) {
                            String id_libro = parts[0].replace("ID: ","").trim();
                            String titolo = parts[1].replace("Titolo: ", "").trim();
                            String autore = parts[2].replace("Autore: ", "").trim();
                            String copieString = parts[3].replace("Copie disponibili: ", "").trim();
                            String genere = parts[4].replace("Genere: ","").trim();


                            int copieDisponibili,id;
                            try {
                                copieDisponibili = Integer.parseInt(copieString);
                                id = Integer.parseInt(id_libro);
                            } catch (NumberFormatException e) {
                                copieDisponibili = 0;
                                id = 0;
                            }

                            libri.add(new Libro(id,titolo, autore, copieDisponibili,genere,0));
                        }
                    }
                }
            }

            if (libri.size() > 0) {
                adapter = new RisultatiAdapter(libri, new RisultatiAdapter.OnItemClickListener() {
                    @Override
                    public void onItemClick(Libro libro) {
                        Controller.getInstance().setLibro(libro);
                        openDettagliLibroActivity(libriArray,libro.getId_libro());
                    }
                },false);
                recyclerView.setAdapter(adapter);
            } else {
                ris.setText("Nessun Risultato Trovato. Prova a cambiare i criteri di Ricerca.");
            }
        } else {
            ris.setText("Nessun Risultato Trovato. Prova a cambiare i criteri di Ricerca.");
        }



        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityCerca();
                finish();
            }
        });

        carrello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityCarrello(libriArray);
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openHomeActivity();
            }
        });


    }

    private void openActivityCerca(){
        Intent intentC = new Intent(this, CercaActivity.class);
        startActivity(intentC);
    }

    protected void openActivityCarrello(String[] libri){
        Intent intent = new Intent(this, CarrelloActivity.class);
        intent.putExtra("fromRisultati",true);
        intent.putExtra("Risultati", libri);
        startActivity(intent);
    }

    private void openHomeActivity(){
        Intent intentH = new Intent(this, HomeActivity.class);
        startActivity(intentH);
    }

    private void openDettagliLibroActivity(String[] libri, int id){
        Intent intentD = new Intent(this, DettagliLibroActivity.class);
        intentD.putExtra("ID",id);
        intentD.putExtra("Risultati", libri);
        startActivity(intentD);
    }
}
