package adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lso_libreria.R;

import java.util.Date;
import java.util.List;

import model.Prestito;


public class PrestitiAdapter extends RecyclerView.Adapter<PrestitiAdapter.CarrelloViewHolder> {

    private final List<Prestito> prestiti;
    private final OnItemClickListener listener;

    public PrestitiAdapter(List<Prestito> prestiti, OnItemClickListener listener) {
        this.prestiti = prestiti;
        this.listener = listener;
    }

    public interface OnItemClickListener {
        void onItemClick(Prestito prestito);
    }

    @NonNull
    @Override
    public CarrelloViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_item_libro, parent, false);
        return new CarrelloViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CarrelloViewHolder holder, int position) {
        Prestito prestito = prestiti.get(position);

        holder.titoloP.setText(prestito.getLibro().getTitolo());
        holder.autoreP.setText(prestito.getLibro().getAutore());
        holder.copieP.setText("   " +prestito.getLibriInPrestito());

        Date dataScadenza = prestito.getData_scadenza();
        Date dataCorrente = new Date();

        if(dataScadenza != null && dataScadenza.before(dataCorrente))
            holder.contenitore.setBackgroundTintList(ContextCompat.getColorStateList(holder.itemView.getContext(), R.color.red));
        else
            holder.contenitore.setBackgroundTintList(ContextCompat.getColorStateList(holder.itemView.getContext(), R.color.white));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(prestito);
            }
        });
    }

    @Override
    public int getItemCount() {
        return prestiti.size();
    }

    public static class CarrelloViewHolder extends RecyclerView.ViewHolder {

        TextView titoloP,autoreP,copieP;
        LinearLayout contenitore;

        public CarrelloViewHolder(@NonNull View itemView) {

            super(itemView);
            titoloP = itemView.findViewById(R.id.titolo);
            autoreP = itemView.findViewById(R.id.autore);
            copieP = itemView.findViewById(R.id.copie);
            contenitore = itemView.findViewById(R.id.layout_contenitore);

        }
    }
}
