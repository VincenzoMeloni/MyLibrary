package adapter;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lso_libreria.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import model.Libro;

public class RisultatiAdapter extends RecyclerView.Adapter<RisultatiAdapter.RisultatiViewHolder> {

    private final List<Libro> risultati;
    private final OnItemClickListener listener;
    private boolean isCarrello;
    private List<Boolean> isSelectedList;
    public RisultatiAdapter(List<Libro> risultati, OnItemClickListener listener,boolean isCarrello) {
        this.risultati = risultati;
        this.listener = listener;
        this.isCarrello = isCarrello;
        if(isCarrello)
            isSelectedList = new ArrayList<>(Collections.nCopies(risultati.size(),false));
    }

    public interface OnItemClickListener {
        void onItemClick(Libro libro);
    }

    public List<Libro> getSelectedItems() {
        List<Libro> selectedItems = new ArrayList<>();
        for (int i = 0; i < isSelectedList.size(); i++) {
            if (isSelectedList.get(i)) {
                selectedItems.add(risultati.get(i));
            }
        }
        return selectedItems;
    }

    @NonNull
    @Override
    public RisultatiViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_item_libro, parent, false);
        return new RisultatiViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RisultatiViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Libro libro = risultati.get(position);

        holder.titolo.setText(libro.getTitolo());
        holder.autore.setText(libro.getAutore());
        holder.copie.setText("   " + String.valueOf(libro.getNum_copie_disponibili()));

        if (isCarrello) {
            boolean isSelected = isSelectedList.get(position);

            if (isSelected)
                holder.contenitore.setBackgroundTintList(ContextCompat.getColorStateList(holder.itemView.getContext(), R.color.dark_gray));  // Colore selezionato
             else
                holder.contenitore.setBackgroundTintList(ContextCompat.getColorStateList(holder.itemView.getContext(), R.color.white)); // Colore non selezionato


            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    isSelectedList.set(position,!isSelected);
                    notifyItemChanged(position);
                }
            });

        } else {
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(libro);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return risultati.size();
    }

    public static class RisultatiViewHolder extends RecyclerView.ViewHolder{

        TextView titolo,autore,copie;
        LinearLayout contenitore;

        public RisultatiViewHolder(@NonNull View itemView) {
            super(itemView);
            titolo = itemView.findViewById(R.id.titolo);
            autore = itemView.findViewById(R.id.autore);
            copie = itemView.findViewById(R.id.copie);
            contenitore = itemView.findViewById(R.id.layout_contenitore);
        }

    }
}
