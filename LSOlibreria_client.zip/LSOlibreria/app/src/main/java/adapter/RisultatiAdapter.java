package adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lso_libreria.R;

import java.util.List;

import model.Libro;

public class RisultatiAdapter extends RecyclerView.Adapter<RisultatiAdapter.RisultatiViewHolder> {

    private final List<Libro> risultati;
    private final OnItemClickListener listener;

    public RisultatiAdapter(List<Libro> risultati, OnItemClickListener listener) {
        this.risultati = risultati;
        this.listener = listener;
    }

    public interface OnItemClickListener {
        void onItemClick(Libro libro);
    }

    @NonNull
    @Override
    public RisultatiViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_item_libro, parent, false);
        return new RisultatiViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RisultatiViewHolder holder, int position) {
        Libro libro = risultati.get(position);

        holder.titolo.setText(libro.getTitolo());
        holder.autore.setText(libro.getAutore());
        holder.copie.setText("   "+ String.valueOf(libro.getNum_copie_disponibili()));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(libro);
            }
        });
    }

    @Override
    public int getItemCount() {
        return risultati.size();
    }

    public static class RisultatiViewHolder extends RecyclerView.ViewHolder{

        TextView titolo,autore,copie;

        public RisultatiViewHolder(@NonNull View itemView) {
            super(itemView);
            titolo = itemView.findViewById(R.id.titolo);
            autore = itemView.findViewById(R.id.autore);
            copie = itemView.findViewById(R.id.copie);
        }

    }
}
