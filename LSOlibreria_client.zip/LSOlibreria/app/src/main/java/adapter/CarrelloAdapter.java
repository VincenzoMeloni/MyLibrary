package adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lso_libreria.R;

import java.util.List;

import model.Libro;

public class CarrelloAdapter extends RecyclerView.Adapter<CarrelloAdapter.CarrelloViewHolder> {

    private final List<Libro> libri;
    private final OnItemClickListener listener;

    public CarrelloAdapter(List<Libro> libri,OnItemClickListener listener) {
        this.libri = libri;
        this.listener = listener;
    }

    public interface OnItemClickListener {
        void onItemClick(Libro libro);
    }

    @NonNull
    @Override
    public CarrelloViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_item_libro, parent, false);
        return new CarrelloViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CarrelloViewHolder holder, int position) {
        Libro libro = libri.get(position);

        holder.titoloC.setText(libro.getTitolo());
        holder.autoreC.setText(libro.getAutore());
        holder.copieC.setText("   "+ String.valueOf(libro.getNum_copie_disponibili()));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(libro);
            }
        });
    }

    @Override
    public int getItemCount() {
        return libri.size();
    }

    public static class CarrelloViewHolder extends RecyclerView.ViewHolder {

        TextView titoloC,autoreC,copieC;

        public CarrelloViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
